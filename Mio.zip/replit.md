# Telegram Media Downloader Bot

A Telegram bot that accepts links from YouTube, Instagram, TikTok, Aparat, Twitter/X, Facebook, Vimeo, and hundreds of other video platforms, downloads the media, and sends it directly to the user in Telegram.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server + Telegram bot (port 8080)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages

## Required Environment Variables

- `TELEGRAM_BOT_TOKEN` — Telegram bot token from @BotFather (stored in shared env)

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- Bot: grammY (Telegram bot framework)
- Downloader: yt-dlp (standalone binary at ~/bin/yt-dlp)
- Logging: pino

## Where things live

- `artifacts/api-server/src/bot/index.ts` — Telegram bot logic (grammy handlers)
- `artifacts/api-server/src/bot/downloader.ts` — yt-dlp download logic
- `artifacts/api-server/src/index.ts` — server entry point (starts both Express + bot)
- `~/bin/yt-dlp` — yt-dlp standalone binary (version 2026.07.04)
- `/tmp/tg-bot-downloads/` — temporary download directory (auto-cleaned)

## Architecture decisions

- Bot runs in the same process as the Express API server (long polling, not webhook)
- yt-dlp standalone binary used (no Python dependency) — lives at `~/bin/yt-dlp`
- Quality ladder: 720p → 480p → 360p → worst, until file fits under 48MB Telegram limit
- Files cleaned up from `/tmp` after successful send
- grammY is externalized in esbuild (not bundled) to avoid module resolution issues

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- yt-dlp binary is at `~/bin/yt-dlp` — if the container restarts it must be re-downloaded (see redownload in post-merge.sh or startup)
- Telegram bots have a 50MB file size limit; bot automatically steps down quality to fit
- Instagram/private content may fail — bot handles this gracefully
- `TELEGRAM_BOT_TOKEN` env var must be set; bot warns but doesn't crash if missing

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
