import { Bot, InputFile } from "grammy";
import { downloadMedia, cleanupFile, detectPlatform } from "./downloader";
import { logger } from "../lib/logger";

const URL_REGEX =
  /https?:\/\/(www\.)?(youtube\.com|youtu\.be|instagram\.com|tiktok\.com|vm\.tiktok\.com|aparat\.com|twitter\.com|x\.com|facebook\.com|fb\.watch|vimeo\.com|dailymotion\.com|twitch\.tv|reddit\.com|pinterest\.com|soundcloud\.com|t\.co)[^\s]*/gi;

function extractUrls(text: string): string[] {
  return [...text.matchAll(URL_REGEX)].map((m) => m[0]);
}

function formatFileSize(bytes: number): string {
  const mb = bytes / (1024 * 1024);
  return `${mb.toFixed(1)} MB`;
}

export function createBot(token: string): Bot {
  const bot = new Bot(token);

  // /start command
  bot.command("start", async (ctx) => {
    await ctx.reply(
      `👋 سلام! من یک ربات دانلودر هستم.\n\n` +
        `🎬 پشتیبانی از:\n` +
        `• یوتیوب (YouTube)\n` +
        `• اینستاگرام (Instagram)\n` +
        `• تیک‌تاک (TikTok)\n` +
        `• آپارات (Aparat)\n` +
        `• توییتر / ایکس (Twitter/X)\n` +
        `• فیسبوک (Facebook)\n` +
        `• ویمئو (Vimeo)\n` +
        `• و صدها سایت دیگر...\n\n` +
        `📎 فقط لینک ویدیو را برای من بفرستید!`
    );
  });

  // /help command
  bot.command("help", async (ctx) => {
    await ctx.reply(
      `📖 راهنما:\n\n` +
        `1️⃣ لینک ویدیو را کپی کنید\n` +
        `2️⃣ لینک را برای من ارسال کنید\n` +
        `3️⃣ صبر کنید تا ویدیو دانلود و ارسال شود\n\n` +
        `⚠️ محدودیت‌ها:\n` +
        `• حداکثر حجم فایل: ۴۸ مگابایت\n` +
        `• ویدیوهای بزرگتر با کیفیت پایین‌تر ارسال می‌شوند\n` +
        `• برخی محتواهای خصوصی قابل دانلود نیستند`
    );
  });

  // Handle any message containing a URL
  bot.on("message:text", async (ctx) => {
    const text = ctx.message.text;
    const urls = extractUrls(text);

    if (urls.length === 0) {
      // No URL found — polite guidance
      await ctx.reply(
        `🔗 لطفاً یک لینک معتبر از یوتیوب، اینستاگرام، تیک‌تاک، آپارات یا سایر سایت‌های ویدیویی بفرستید.\n\nبرای راهنمایی بیشتر /help را بزنید.`
      );
      return;
    }

    for (const url of urls) {
      const platform = detectPlatform(url);
      const statusMsg = await ctx.reply(
        `⏳ در حال دانلود از ${platform}...\nلطفاً صبر کنید.`
      );

      try {
        // Send "uploading" action
        await ctx.api.sendChatAction(ctx.chat.id, "upload_video");

        const result = await downloadMedia(url);

        logger.info(
          { platform, title: result.title, size: result.fileSize },
          "Download complete, sending to Telegram"
        );

        // Delete status message
        await ctx.api
          .deleteMessage(ctx.chat.id, statusMsg.message_id)
          .catch(() => {});

        const caption =
          `🎬 ${result.title}\n` +
          `📦 حجم: ${formatFileSize(result.fileSize)}\n` +
          `🌐 منبع: ${platform}`;

        // Send as video (Telegram will show inline player)
        try {
          await ctx.replyWithVideo(new InputFile(result.filePath), {
            caption,
            supports_streaming: true,
          });
        } catch {
          // Fallback to document if video sending fails
          await ctx.replyWithDocument(new InputFile(result.filePath), {
            caption,
          });
        }

        await cleanupFile(result.filePath);
      } catch (err) {
        logger.error({ err, url }, "Failed to download or send media");

        await ctx.api
          .deleteMessage(ctx.chat.id, statusMsg.message_id)
          .catch(() => {});

        const errMsg = err instanceof Error ? err.message : String(err);

        if (errMsg.includes("timed out")) {
          await ctx.reply(
            `⏱️ دانلود بیش از حد طول کشید. لطفاً دوباره امتحان کنید یا لینک دیگری بفرستید.`
          );
        } else if (
          errMsg.includes("Private") ||
          errMsg.includes("private") ||
          errMsg.includes("login") ||
          errMsg.includes("Login")
        ) {
          await ctx.reply(
            `🔒 این محتوا خصوصی است و قابل دانلود نیست.\nلطفاً لینک یک ویدیو عمومی بفرستید.`
          );
        } else if (
          errMsg.includes("available") ||
          errMsg.includes("removed") ||
          errMsg.includes("deleted")
        ) {
          await ctx.reply(
            `❌ این ویدیو در دسترس نیست. ممکن است حذف شده باشد.`
          );
        } else {
          await ctx.reply(
            `❌ خطا در دانلود ویدیو.\n\n` +
              `ممکن است:\n` +
              `• لینک اشتباه باشد\n` +
              `• محتوا خصوصی باشد\n` +
              `• سایت موقتاً دسترسی را محدود کرده باشد\n\n` +
              `لطفاً دوباره امتحان کنید.`
          );
        }
      }
    }
  });

  // Handle errors
  bot.catch((err) => {
    logger.error({ err: err.error, ctx: err.ctx?.update }, "Bot error");
  });

  return bot;
}

export async function startBot(token: string): Promise<Bot> {
  const bot = createBot(token);
  // Start long polling (no webhook needed)
  bot.start({
    onStart: (botInfo) => {
      logger.info({ username: botInfo.username }, "Telegram bot started");
    },
  });
  return bot;
}
