import { spawn } from "child_process";
import { stat, mkdir, unlink, readdir } from "fs/promises";
import { join } from "path";
import { randomUUID } from "crypto";
import { existsSync } from "fs";
import { logger } from "../lib/logger";

const YT_DLP_PATH = `${process.env.HOME}/bin/yt-dlp`;
const TEMP_DIR = "/tmp/tg-bot-downloads";
const MAX_SIZE_BYTES = 48 * 1024 * 1024; // 48MB

export interface DownloadResult {
  filePath: string;
  title: string;
  ext: string;
  fileSize: number;
}

async function ensureTempDir() {
  if (!existsSync(TEMP_DIR)) {
    await mkdir(TEMP_DIR, { recursive: true });
  }
}

function runYtDlp(
  args: string[],
  timeoutMs = 120_000
): Promise<{ stdout: string; stderr: string }> {
  return new Promise((resolve, reject) => {
    logger.debug({ args }, "Running yt-dlp");
    const proc = spawn(YT_DLP_PATH, args);
    let stdout = "";
    let stderr = "";

    proc.stdout.on("data", (d: Buffer) => {
      stdout += d.toString();
    });
    proc.stderr.on("data", (d: Buffer) => {
      stderr += d.toString();
    });

    const timer = setTimeout(() => {
      proc.kill("SIGKILL");
      reject(new Error("yt-dlp timed out"));
    }, timeoutMs);

    proc.on("close", (code) => {
      clearTimeout(timer);
      if (code === 0) {
        resolve({ stdout, stderr });
      } else {
        reject(new Error(`yt-dlp exited with code ${code}: ${stderr.slice(-500)}`));
      }
    });

    proc.on("error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

/** Find files in TEMP_DIR that start with the given ID prefix */
async function findDownloadedFiles(id: string): Promise<string[]> {
  const files = await readdir(TEMP_DIR);
  return files
    .filter((f) => f.startsWith(id))
    .map((f) => join(TEMP_DIR, f));
}

/** Supported platforms for display in error messages */
export function detectPlatform(url: string): string {
  if (/youtube\.com|youtu\.be/i.test(url)) return "YouTube";
  if (/instagram\.com/i.test(url)) return "Instagram";
  if (/tiktok\.com/i.test(url)) return "TikTok";
  if (/aparat\.com/i.test(url)) return "Aparat";
  if (/twitter\.com|x\.com/i.test(url)) return "Twitter/X";
  if (/facebook\.com|fb\.watch/i.test(url)) return "Facebook";
  if (/vimeo\.com/i.test(url)) return "Vimeo";
  if (/dailymotion\.com/i.test(url)) return "Dailymotion";
  if (/twitch\.tv/i.test(url)) return "Twitch";
  if (/reddit\.com/i.test(url)) return "Reddit";
  if (/pinterest\.com/i.test(url)) return "Pinterest";
  if (/soundcloud\.com/i.test(url)) return "SoundCloud";
  return "Unknown";
}

/** Try downloading with different quality settings until under size limit */
export async function downloadMedia(url: string): Promise<DownloadResult> {
  await ensureTempDir();

  const id = randomUUID();
  const outputTemplate = join(TEMP_DIR, `${id}.%(ext)s`);

  // Quality fallback ladder — prefer mp4, step down in resolution
  const formatLadder = [
    "bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=720]+bestaudio/best[height<=720][ext=mp4]/best[height<=720]",
    "bestvideo[height<=480][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=480]+bestaudio/best[height<=480][ext=mp4]/best[height<=480]",
    "bestvideo[height<=360]+bestaudio/best[height<=360]",
    "worst[ext=mp4]/worst",
  ];

  let lastError: Error | null = null;

  for (const format of formatLadder) {
    const filesBeforeDownload = existsSync(TEMP_DIR)
      ? await readdir(TEMP_DIR)
      : [];

    try {
      await runYtDlp([
        "-f",
        format,
        "--merge-output-format",
        "mp4",
        "--no-playlist",
        "--no-warnings",
        "--no-check-certificates",
        "-o",
        outputTemplate,
        url,
      ]);

      // Find newly created files
      const allFiles = await findDownloadedFiles(id);
      if (allFiles.length === 0) continue;

      // Pick the video file (prefer mp4)
      const videoFile =
        allFiles.find((f) => f.endsWith(".mp4")) ??
        allFiles.find((f) => /\.(mkv|webm|mov|avi|flv)$/.test(f)) ??
        allFiles[0];

      if (!videoFile || !existsSync(videoFile)) continue;

      const stats = await stat(videoFile);
      logger.info(
        { size: stats.size, file: videoFile },
        "Downloaded file info"
      );

      if (stats.size > MAX_SIZE_BYTES) {
        // Too large — clean up and try next quality
        for (const f of allFiles) await unlink(f).catch(() => {});
        logger.info({ size: stats.size, format }, "File too large, retrying lower quality");
        continue;
      }

      const ext = videoFile.split(".").pop() ?? "mp4";

      // Extract title from yt-dlp info (best effort)
      let title = "video";
      try {
        const infoResult = await runYtDlp([
          "--dump-single-json",
          "--no-warnings",
          "--no-playlist",
          url,
        ]);
        const info = JSON.parse(infoResult.stdout) as { title?: string };
        if (info.title) title = info.title.slice(0, 100);
      } catch {
        // Not critical
      }

      return { filePath: videoFile, title, ext, fileSize: stats.size };
    } catch (err) {
      // Clean up any partial files for this attempt
      const newFiles = await findDownloadedFiles(id);
      for (const f of newFiles) await unlink(f).catch(() => {});

      lastError = err instanceof Error ? err : new Error(String(err));
      logger.warn({ err: lastError.message, format }, "Download attempt failed");
    }
  }

  throw lastError ?? new Error("All download attempts failed");
}

export async function cleanupFile(filePath: string): Promise<void> {
  await unlink(filePath).catch((err) => {
    logger.warn({ err, filePath }, "Failed to clean up temp file");
  });
}
