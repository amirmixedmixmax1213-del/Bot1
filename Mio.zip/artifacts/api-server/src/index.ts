import app from "./app";
import { logger } from "./lib/logger";
import { startBot } from "./bot/index";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
});

// Start Telegram bot
const botToken = process.env["TELEGRAM_BOT_TOKEN"];
if (!botToken) {
  logger.warn("TELEGRAM_BOT_TOKEN is not set — Telegram bot will not start");
} else {
  startBot(botToken).catch((err) => {
    logger.error({ err }, "Failed to start Telegram bot");
  });
}
